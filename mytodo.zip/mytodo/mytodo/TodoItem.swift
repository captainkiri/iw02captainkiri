//
//  TodoItem.swift
//  mytodo
//
//  Created by 李正浩 on 2021/10/18.
//

import UIKit

class TodoItem: NSObject,Encodable,Decodable {
    var title:String
    var isChecked: Bool
    
    init(title:String, isChecked:Bool){
        self.isChecked = isChecked
        self.title = title
    }

}
