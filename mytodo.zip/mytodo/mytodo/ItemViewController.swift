//
//  ItemViewController.swift
//  mytodo
//
//  Created by 李正浩 on 2021/10/18.
//

import UIKit

//建立协议
protocol AddItemDelegate{
    func addItem(item: TodoItem)
}

protocol EditItemDelegate{
    func editItem(newItem: TodoItem, itemIndex: Int)
}

class ItemViewController: UIViewController {
    @IBOutlet weak var doneButton: UIButton!
    @IBOutlet weak var titleInput: UITextField!
    @IBOutlet weak var isChecked: UISwitch!
    
    var addItemDelegate: AddItemDelegate?
    var editItemDelegate: EditItemDelegate?
    var itemToedit: TodoItem?
    var itemIndex: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        doneButton.isEnabled = false
        if itemToedit != nil{
            doneButton.isEnabled = true
            self.titleInput.text! = itemToedit!.title
            self.isChecked.isOn = itemToedit!.isChecked
        }
    }
    
    @IBAction func cancle(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func done(_ sender: Any) {
        if itemToedit == nil{
            self.addItemDelegate?.addItem(item: TodoItem(title: titleInput.text!, isChecked: isChecked.isOn))
        } else {
            self.editItemDelegate?.editItem(newItem: TodoItem(title: titleInput.text!, isChecked: isChecked.isOn), itemIndex: self.itemIndex)
        }
        self.dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


extension ItemViewController: UITextFieldDelegate{
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let oldText = textField.text!
        let stringRange = Range(range, in:oldText)!
        let newText = oldText.replacingCharacters(in: stringRange, with:string)
        doneButton.isEnabled = !newText.isEmpty
        return true
        
    }
}
